# GrafikaOpenGL-Draw

# Reference:

http://www.falloutsoftware.com/tutorials/gl/gl3.htm

http://stackoverflow.com/questions/26700719/pyopengl-glutinit-nullfunctionerror


# Anggota Kelompok:

Hendrikus Bimawan Satrianto - 13514066

Deny Krisna - 13514096

Azka Hanif - 13514086

Ali Akbar - 13514080